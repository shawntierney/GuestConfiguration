#!/bin/bash
# 
# This script enables DSC on Linux by starting the DSC service.
#

DSC_HOME_PATH="$PWD"
SERVICE_SCRIPTS_FOLDER_PATH="$DSC_HOME_PATH/service_scripts"
SERVICE_CONTROLLER_PATH="$SERVICE_SCRIPTS_FOLDER_PATH/dsc_service_controller"

print_error() {
  echo "[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $@" >&2
}

check_result() {
    if [ $1 -ne 0 ]; then
        print_error $2
        exit $1
    fi
}

start_dsc_service() {
    $SERVICE_CONTROLLER_PATH start
    check_result $? "Starting the DSC service failed"
}

enable_dsc() {
    start_dsc_service
}

enable_dsc
